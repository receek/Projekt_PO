﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjektPO{
    public class KlasaLampki : Nadklasa{
        public KlasaLampki(int x, Home h){
            Klatka.Content = new Lampka(x, h);
        }
        public override string SwitchSensorOFF(int x)
        {
            return SendMessage("COM "+ x.ToString() + " STP\n");
        }
        public override string SwitchSensorON(int x)
        {
            return SendMessage("COM " + x.ToString() + " STR\n");
        }
        public override string AskIntensity(int id)
        {
            return SendMessage("VAL " + id.ToString() + "\n");
        }
    }
}
